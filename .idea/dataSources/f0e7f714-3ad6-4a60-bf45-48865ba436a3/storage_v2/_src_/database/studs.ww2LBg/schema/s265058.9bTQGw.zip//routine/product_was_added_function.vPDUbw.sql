create function product_was_added_function() returns trigger
    language plpgsql
as
$$
BEGIN
        UPDATE trip
            SET product_count = product_count + 1
            WHERE trip_id = new.trip_id;
        RETURN new;
    END;
$$;

alter function product_was_added_function() owner to s265058;

