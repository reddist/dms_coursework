create function get_cart_capacity(integer) returns integer
    language plpgsql
as
$$
begin
        if $1 IS NULL then
            return 0;
        end if;
        return (select capacity from cart where cart_id = $1);
    end;
$$;

alter function get_cart_capacity(integer) owner to aleksey;

