create function horse_was_updated_function() returns trigger
    language plpgsql
as
$$
BEGIN
        UPDATE horse
            SET last_care_date = CURRENT_DATE
            WHERE horse_id = NEW.horse_id
                AND OLD.status = 'under care'
                AND NEW.status != 'under care';
        RETURN new;
    END;
$$;

alter function horse_was_updated_function() owner to aleksey;

