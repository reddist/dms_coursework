create function cell_was_deleted_function() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE pick_up_point
        SET number_of_cells = number_of_cells - 1
        WHERE pick_up_point_id = OLD.pick_up_point_id;
    UPDATE pick_up_point
        SET number_of_free_cells = number_of_free_cells - 1
        WHERE pick_up_point_id = OLD.pick_up_point_id
            AND OLD.status = 'available';
    RETURN old;
END;
$$;

alter function cell_was_deleted_function() owner to aleksey;

